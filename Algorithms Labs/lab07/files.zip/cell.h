// Definition of the cell data type

// !!! DO NOT MODIFY THIS FILE !!!

#ifndef CELL_H
#define CELL_H

struct cell {
    int row;
    int col;
};

#endif
